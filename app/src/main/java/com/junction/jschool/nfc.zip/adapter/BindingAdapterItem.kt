package com.example.nfc.adapter

interface BindingAdapterItem {
    /**
     * 返回View类型
     * @return Int
     */
    fun getViewType(): Int
}